import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {
  IonContent, IonGrid, IonRow, IonCol, IonIcon, IonList, IonItem, IonLabel,
  IonButton, IonChip, IonCard, IonCardContent, IonCardHeader, IonCardTitle,
  ViewWillEnter
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  shieldCheckmarkOutline, peopleOutline, businessOutline, chatbubblesOutline,
  logOutOutline, personCircleOutline, ribbonOutline, checkmarkOutline, closeOutline
} from 'ionicons/icons';
import { AuthService } from '../services/auth'; 

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.page.html',
  styleUrls: ['./admin-panel.page.scss'],
  standalone: true,
  imports: [
    CommonModule, FormsModule, IonContent, IonGrid, IonRow, IonCol, IonIcon,
    IonList, IonItem, IonLabel, IonButton, IonChip, IonCard, IonCardContent,
    IonCardHeader, IonCardTitle
  ]
})
export class AdminPanelPage implements OnInit, ViewWillEnter {
  
  solicitudesPendientes: any[] = [];

  constructor(
    private router: Router,
    private authService: AuthService,
    private http: HttpClient,
    private cdr: ChangeDetectorRef // Inyectamos el detector de cambios
  ) {
    addIcons({
      shieldCheckmarkOutline, peopleOutline, businessOutline, chatbubblesOutline,
      logOutOutline, personCircleOutline, ribbonOutline, checkmarkOutline, closeOutline
    });
  }

  ngOnInit() {}

  ionViewWillEnter() {
    const currentUser: any = this.authService.getCurrentUser() || {};
    const rolActual = currentUser.role || currentUser.tipo_usuario;

    if (rolActual !== 'admin') {
      alert('Acceso denegado. Serás redirigido al inicio.');
      this.router.navigate(['/home']);
      return;
    }
    
    // AQUÍ ESTÁ EL PUENTE: Apenas entra, pide los datos
    this.cargarSolicitudes();
  }

  cargarSolicitudes() {
    console.log('Pidiendo datos al backend...'); 
    
    this.http.get<any[]>('http://localhost:3000/api/solicitudes/pendientes').subscribe({
      next: (data) => {
        console.log('Datos recibidos con éxito:', data);
        this.solicitudesPendientes = data;
        this.cdr.detectChanges(); // Fuerza a Ionic a dibujar la tabla
      },
      error: (err) => {
        console.error('Error al cargar solicitudes:', err);
      }
    });
  }

  aprobarSolicitud(idSolicitud: number) {
    this.http.post(`http://localhost:3000/api/solicitudes/aprobar/${idSolicitud}`, {}).subscribe({
      next: () => {
        alert('Solicitud aprobada: Junta creada y presidente asignado.');
        this.cargarSolicitudes(); // Recarga la tabla para que desaparezca la fila
      },
      error: (err) => console.error('Error al aprobar:', err)
    });
  }

  rechazarSolicitud(idSolicitud: number) {
    this.http.post(`http://localhost:3000/api/solicitudes/rechazar/${idSolicitud}`, {}).subscribe({
      next: () => {
        alert('Solicitud rechazada.');
        this.cargarSolicitudes();
      },
      error: (err) => console.error('Error al rechazar:', err)
    });
  }

  volverAlHome() {
    this.router.navigate(['/home']);
  }
}