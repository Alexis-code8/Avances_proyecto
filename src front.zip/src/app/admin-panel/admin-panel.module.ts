
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import {
  IonContent,
  IonGrid,
  IonRow,
  IonCol,
  IonIcon,
  IonList,
  IonItem,
  IonLabel,
  IonButton,
  IonChip,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  ViewWillEnter
} from '@ionic/angular';

import { addIcons } from 'ionicons';

import {
  shieldCheckmarkOutline,
  peopleOutline,
  businessOutline,
  chatbubblesOutline,
  logOutOutline,
  personCircleOutline,
  ribbonOutline
} from 'ionicons/icons';

import { AuthService } from '../services/auth';
import { JuntaVecinosService } from '../services/junta-vecinos.service';

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.page.html',
  styleUrls: ['./admin-panel.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonGrid,
    IonRow,
    IonCol,
    IonIcon,
    IonList,
    IonItem,
    IonLabel,
    IonButton,
    IonChip,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle
  ]
})
export class AdminPanelPage implements OnInit, ViewWillEnter {

  // ==========================================
  // DATOS DEL DASHBOARD
  // ==========================================

  juntasRegistradas = 0;
  vecinosRegistrados = 0;
  presidentesActivos = 0;

  constructor(
    private router: Router,
    private authService: AuthService,
    private juntaVecinosService: JuntaVecinosService
  ) {
    addIcons({
      shieldCheckmarkOutline,
      peopleOutline,
      businessOutline,
      chatbubblesOutline,
      logOutOutline,
      personCircleOutline,
      ribbonOutline
    });
  }

  ngOnInit() {
  }

  // ==========================================
  // AL ENTRAR AL PANEL
  // ==========================================

  ionViewWillEnter() {

    const currentUser = this.authService.getCurrentUser();

    // Verificar que sea administrador
    if (!currentUser || currentUser.role !== 'admin') {

      alert('Acceso denegado. Serás redirigido al inicio.');

      this.router.navigate(['/home']);

      return;
    }

    console.log('Validación exitosa: Bienvenido Admin');

    // Cargar estadísticas reales
    this.cargarDashboard();
  }

  // ==========================================
  // CARGAR DATOS DESDE EL BACKEND
  // ==========================================

  cargarDashboard() {

    this.juntaVecinosService.obtenerDashboard().subscribe({

      next: (data) => {

        console.log('Datos del dashboard:', data);

        this.juntasRegistradas = data.juntasRegistradas;
        this.vecinosRegistrados = data.vecinosRegistrados;
        this.presidentesActivos = data.presidentesActivos;

      },

      error: (error) => {

        console.error(
          'Error al obtener los datos del dashboard:',
          error
        );

      }

    });

  }

  // ==========================================
  // VOLVER AL HOME
  // ==========================================

  volverAlHome() {
    this.router.navigate(['/home']);
  }
}
```