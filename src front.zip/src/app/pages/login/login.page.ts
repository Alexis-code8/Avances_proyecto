import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { 
  IonContent, IonItem, IonInput, IonButton, IonIcon, IonText, 
  IonModal, IonHeader, IonToolbar, IonTitle, IonButtons 
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import { mailOutline, lockClosedOutline, personOutline, cardOutline, locationOutline, closeOutline, eyeOutline, eyeOffOutline } from 'ionicons/icons';
import { AuthService } from '../../services/auth';

addIcons({
  'mail-outline': mailOutline,
  'lock-closed-outline': lockClosedOutline,
  'person-outline': personOutline,
  'card-outline': cardOutline,
  'location-outline': locationOutline,
  'close-outline': closeOutline,
  'eye-outline': eyeOutline,
  'eye-off-outline': eyeOffOutline
});

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonItem,
    IonInput,
    IonButton,
    IonIcon,
    IonText,
    IonModal,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons
  ]
})
export class LoginPage {
  email: string = '';
  password: string = '';
  errorMessage: string = '';

  isRegisterOpen: boolean = false;
  regNombre: string = '';
  regRut: string = '';
  regSector: string = '';
  regEmail: string = '';
  regPassword: string = '';
  regError: string = '';
  regSuccess: string = '';
  
  showPassword: boolean = false; // Estado inicial oculto

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  constructor(private authService: AuthService, private router: Router) {}

  onLogin() {
    if (!this.email || !this.password) {
      this.errorMessage = 'Ingresa correo y contraseña.';
      return;
    }

    // Mantenemos el acceso rápido de administrador si lo necesitas
    if (this.email === 'admin@barrio.cl' && this.password === 'admin') {
      this.authService.setCurrentUser({
        rut: '12345678-9',
        nombre: 'Administrador',
        correo: 'admin@barrio.cl',
        tipo_usuario: 'admin',
        role: 'admin',
        sector: 'Central',
        junta_vecinos_id_junta_vecinos: 1
      });
      this.router.navigate(['/home']);
      return;
    }

    // --- NUEVO: Llamamos a la ruta de login del backend que valida contraseña ---
    this.authService.loginMysql(this.email, this.password).subscribe({
      next: (res: any) => {
        if (res.ok) {
          this.errorMessage = '';
          this.authService.setCurrentUser(res.data);
          this.router.navigate(['/home']);
        } else {
          // Si el backend responde ok: false (contraseña mala o correo no existe)
          this.errorMessage = res.message || 'Correo o contraseña incorrectos.';
        }
      },
      error: (err) => {
        console.error(err);
        this.errorMessage = 'Error al conectar con el servidor backend.';
      }
    });
  }

  openRegister() {
    this.isRegisterOpen = true;
    this.regError = '';
    this.regSuccess = '';
  }

  closeRegister() {
    this.isRegisterOpen = false;
  }

  isSubmitting: boolean = false; // <--- Agrega esta variable arriba con tus otras variables

  onRegisterSubmit() {
    if (this.isSubmitting) return;

    if (!this.regNombre || !this.regRut || !this.regEmail || !this.regPassword || !this.regSector) {
      this.regError = 'Por favor completa todos los campos obligatorios.';
      return;
    }

    this.isSubmitting = true;
    this.regError = '';
    this.regSuccess = '¡Registrado con éxito!';

    this.authService.register(
      this.regNombre, 
      this.regRut, 
      this.regEmail, 
      this.regPassword, 
      this.regSector
    ).subscribe({
      next: () => {
        setTimeout(() => {
          this.closeRegister();
          this.isSubmitting = false; // Liberamos el botón al cerrar
          this.regNombre = '';
          this.regRut = '';
          this.regSector = '';
          this.regEmail = '';
          this.regPassword = '';
          this.regSuccess = '';
        }, 1000);
      },
      error: (err) => {
        console.error(err);
        this.regError = 'Ocurrió un error al registrar en el servidor.';
        this.isSubmitting = false; // Liberamos el botón si hay error
        this.regSuccess = '';
      }
    });
  }
}