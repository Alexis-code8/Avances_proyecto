import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {
  nom:string="";
  email:string="";
  comentario:string="";

  constructor(private menu:MenuController,
    private alertcontroller: AlertController,
              private router: Router
  ) { }

  ngOnInit() {
  }
  mostrarMenu(){
    this.menu.open('first');  //activa el menú acoplado
  }//fin metodo

  async mostrarMensaje(){
    const alert = await this.alertcontroller.create({
      header: 'Confirmación!',
      message:'Gracias por contactarse con nosotros! '+ this.email,
      mode:'ios',
      buttons: [
       {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            console.log('Datos enviados');
            this.router.navigate(['/inicio']);
            this.limpiar();
          },
        },
      ],
    });
    await alert.present();
    }//finMetodo
  
    limpiar(){
      this.nom="";
      this.email="";
      this.comentario="";
    }

}
