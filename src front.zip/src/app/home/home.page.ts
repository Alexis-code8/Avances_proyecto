import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonHeader,
  IonToolbar,
  IonAvatar,
  IonContent,
  IonSearchbar,
  IonChip,
  IonLabel,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonBadge,
  IonFab,
  IonFabButton,
  IonModal,
  IonTitle,
  IonButtons,
  IonTextarea,
  IonItem,
  IonInput
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  addOutline,
  megaphoneOutline,
  pricetagOutline,
  shieldCheckmarkOutline,
  locationOutline,
  timeOutline,
  personCircleOutline,
  searchOutline,
  checkmarkCircleOutline,
  trashOutline,
  peopleOutline,
  logOutOutline,
  ribbonOutline,
  closeOutline
} from 'ionicons/icons';
import { AuthService, UserRole, UserSession, SolicitudJefe } from '../services/auth';

type FeedType = 'aviso' | 'marketplace' | 'reporte';

interface FeedItem {
  id: number;
  type: FeedType;
  icon: string;
  iconClass: string;
  author: string;
  time: string;
  title: string;
  description: string;
  price?: string;
  location?: string;
  status?: string;
  actionLabel: string;
}

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonAvatar,
    IonContent,
    IonSearchbar,
    IonChip,
    IonLabel,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonBadge,
    IonFab,
    IonFabButton,
    IonModal,
    IonTitle,
    IonButtons,
    IonTextarea,
    IonItem,
    IonInput
    
  ]
})
export class HomePage implements OnInit {
  currentUser: UserSession | null = null;
  usuarioActual: any = {}; // Variable conectada para que funcione el HTML
  currentRole: UserRole = 'vecino';
  searchTerm = '';
  selectedFilter: 'todos' | FeedType = 'todos';

  solicitudesPendientes: SolicitudJefe[] = [];

  // Modal postulación a Jefe
  isPostularOpen = false;
  motivoPostulacion = '';
  
  idUsuarioAscenso!: number;

  feedItems: FeedItem[] = [
    {
      id: 1,
      type: 'aviso',
      icon: 'megaphone-outline',
      iconClass: 'icon-aviso',
      author: 'Junta de Vecinos · Sector Norte',
      time: 'Hace 2 horas',
      title: 'Reunión ordinaria de seguridad',
      description: 'Definición del presupuesto para la mejora de luminarias y nuevo cierre perimetral.',
      actionLabel: 'Ver más'
    },
    {
      id: 2,
      type: 'marketplace',
      icon: 'pricetag-outline',
      iconClass: 'icon-marketplace',
      author: 'María Torres',
      time: 'Hace 5 horas',
      title: 'Bicicleta rodado 26, poco uso',
      description: 'Vendo o permuto por herramientas de jardín.',
      price: '$45.000',
      location: 'A 4 cuadras',
      actionLabel: 'Contactar'
    },
    {
      id: 3,
      type: 'reporte',
      icon: 'shield-checkmark-outline',
      iconClass: 'icon-reporte',
      author: 'Vecino verificado',
      time: 'Ayer',
      title: 'Bache profundo en Calle Los Aromos',
      description: 'A la altura del número 245.',
      status: 'En revisión',
      actionLabel: 'Ver más'
    }
  ];

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    addIcons({
      addOutline,
      megaphoneOutline,
      pricetagOutline,
      shieldCheckmarkOutline,
      locationOutline,
      timeOutline,
      personCircleOutline,
      searchOutline,
      checkmarkCircleOutline,
      trashOutline,
      peopleOutline,
      logOutOutline,
      ribbonOutline,
      closeOutline
    });
  }

  ngOnInit(): void {
    this.refreshSessionData();
  }

  refreshSessionData(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.usuarioActual = this.currentUser || {}; // Sincronización automática de datos

    if (!this.currentUser) {
      this.router.navigate(['/login']);
      return;
    }
    this.currentRole = this.currentUser.role;
    if (this.currentRole === 'admin') {
      this.solicitudesPendientes = this.authService.getSolicitudesPendientes();
    }
  }

  abrirModalPostulacion(): void {
    this.motivoPostulacion = '';
    this.isPostularOpen = true;
  }

  cerrarModalPostulacion(): void {
    this.isPostularOpen = false;
  }

  enviarPostulacion(): void {
    if (!this.currentUser) return;
    const motivoFinal = this.motivoPostulacion.trim() || 'Presidente electo de la junta de vecinos del sector.';
    this.authService.postularAJefe(this.currentUser.rut, motivoFinal);
    this.cerrarModalPostulacion();
    this.refreshSessionData();
  }

  resolverSolicitud(rut: string, aprobar: boolean): void {
    this.authService.resolverSolicitud(rut, aprobar);
    this.refreshSessionData();
  }

  marcarGestionado(item: FeedItem): void {
    item.status = 'Resuelto';
  }

  eliminarItem(id: number): void {
    this.feedItems = this.feedItems.filter(item => item.id !== id);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  get filteredItems(): FeedItem[] {
    let items = this.feedItems;
    if (this.selectedFilter !== 'todos') {
      items = items.filter(item => item.type === this.selectedFilter);
    }
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      items = items.filter(item =>
        item.title.toLowerCase().includes(term) ||
        item.description.toLowerCase().includes(term)
      );
    }
    return items;
  }
  hacerPresidente(id: number) {
    this.authService.ascenderUsuario(id).subscribe({
      next: (respuesta) => {
        alert('¡Usuario ascendido a presidente exitosamente!');
        // Aquí podrías recargar la lista de usuarios si tuvieras una
      },
      error: (error) => {
        console.error('Error al intentar ascender al usuario:', error);
        alert('Hubo un error al ascender al usuario.');
      }
    });
  }
}