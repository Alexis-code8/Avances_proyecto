import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {
  ViewWillEnter, IonHeader, IonToolbar, IonAvatar, IonContent, IonSearchbar, IonChip,
  IonLabel, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle,
  IonCardContent, IonButton, IonIcon, IonBadge, IonFab, IonFabButton,
  IonModal, IonTitle, IonButtons, IonTextarea, IonItem, IonInput, IonSelect, IonSelectOption, IonList, IonListHeader,
  IonRow, IonCol // <-- AGREGADOS AQUÍ
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  addOutline, megaphoneOutline, pricetagOutline, shieldCheckmarkOutline,
  locationOutline, timeOutline, personCircleOutline, searchOutline,
  checkmarkCircleOutline, trashOutline, peopleOutline, logOutOutline,
  ribbonOutline, closeOutline, lockClosedOutline, businessOutline,
  arrowBackOutline, checkmarkDoneOutline, alertCircleOutline,
  documentTextOutline, arrowForwardOutline, hourglassOutline,
  keyOutline, chatbubblesOutline, moonOutline, sunnyOutline,
  idCardOutline, statsChartOutline, personAddOutline, notificationsOutline, notificationsOffOutline } from 'ionicons/icons';
import { AuthService, UserRole, UserSession, SolicitudJefe } from '../services/auth';

export interface Comunidad {
  id: string | number;
  nombre: string;
  comuna: string;
  descripcion: string;
  jefeRut: string;
  miembrosRuts: string[];
}

export interface SolicitudVecinoComunidad {
  id: number;
  vecinoNombre: string;
  vecinoRut: string;
}

type FeedType = 'aviso' | 'marketplace' | 'reporte';

interface FeedItem {
  id?: number;
  comunidadId?: string | number;
  type: FeedType;
  icon?: string;
  iconClass?: string;
  author: string;
  time: string;
  title: string;
  description: string;
  price?: string;
  location?: string;
  status?: string;
  actionLabel?: string;
}

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule, FormsModule, IonHeader, IonToolbar, IonAvatar, IonContent,
    IonSearchbar, IonChip, IonLabel, IonCard, IonCardHeader, IonCardTitle,
    IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonBadge, IonFab,
    IonFabButton, IonModal, IonTitle, IonButtons, IonTextarea, IonItem, IonInput, 
    IonSelect, IonSelectOption, IonList, IonListHeader,
    IonRow, IonCol // <-- AGREGADOS AQUÍ TAMBIÉN
  ]
})
export class HomePage implements OnInit, ViewWillEnter {
  currentUser: UserSession | null = null;
  usuarioActual: any = {}; 
  currentRole: UserRole | 'presidente' = 'vecino';
  isDarkMode = false;
  vistaActual: 'lista' | 'feed' = 'lista';
  searchTerm = '';
  searchComunidad = '';
  selectedComunidadId: string | number | null = null;

  comunidadesGlobales: Comunidad[] = [];
  solicitudesJefeAdmin: SolicitudJefe[] = [];
  miComunidadJefe: Comunidad | null = null;
  solicitudesVecinosJefe: SolicitudVecinoComunidad[] = [];
  misComunidadesVecino: Comunidad[] = [];

  isModalCrearComunidadOpen = false;
  nuevaComunidadNombre = ''; 

  isPostularJefeOpen = false;
  motivoPostulacionJefe = '';

  idUsuarioAscenso!: number;
  correoVecinoVincular: string = '';
  idJuntaVincular!: number;

  feedItems: FeedItem[] = [];
  
  isCrearEventoOpen = false;
  nuevoEvento: FeedItem = { type: 'aviso', title: '', description: '', author: '', time: '', price: '', location: '' };

  // VARIABLE PARA LA PANTALLA DE CARGA
  cargandoFalso: boolean = true;

  private apiUrlEventos = 'http://localhost:3000/api/eventos';
  private apiUrlJuntas = 'http://localhost:3000/api/juntas'; 

  constructor(
    private authService: AuthService,
    private router: Router,
    private http: HttpClient,
    private cdr: ChangeDetectorRef 
  ) {
    addIcons({arrowBackOutline,notificationsOutline,logOutOutline,idCardOutline,businessOutline,locationOutline,arrowForwardOutline,chatbubblesOutline,personCircleOutline,searchOutline,personAddOutline,timeOutline,addOutline,closeOutline,notificationsOffOutline,megaphoneOutline,pricetagOutline,shieldCheckmarkOutline,checkmarkCircleOutline,trashOutline,peopleOutline,ribbonOutline,lockClosedOutline,checkmarkDoneOutline,alertCircleOutline,documentTextOutline,hourglassOutline,keyOutline,moonOutline,sunnyOutline,statsChartOutline});
  }

  misNotificaciones: any[] = [];
  isNotificacionesOpen = false;

  ngOnInit(): void {
    this.initDarkMode();
    this.cargarEventos();
  }

  ionViewWillEnter(): void {
    // ENCIENDE LA PANTALLA DE CARGA AL ENTRAR
    this.cargandoFalso = true;

    // ESPERA 2.5 SEGUNDOS Y LUEGO OCULTA LA PANTALLA DE CARGA
    setTimeout(() => {
      this.cargandoFalso = false;
      this.cdr.detectChanges(); 
    }, 2500);

    this.refreshSessionData();
    this.cargarNotificaciones(); // <-- Carga las notificaciones automáticamente al entrar
    this.vistaActual = 'lista';
    this.selectedComunidadId = null;
  }

  initDarkMode(): void {
    const saved = localStorage.getItem('barrio_dark_mode');
    this.isDarkMode = saved !== null ? saved === 'true' : window.matchMedia('(prefers-color-scheme: dark)').matches;
    this.applyDarkMode();
  }

  toggleDarkMode(): void {
    this.isDarkMode = !this.isDarkMode;
    localStorage.setItem('barrio_dark_mode', String(this.isDarkMode));
    this.applyDarkMode();
  }

  private applyDarkMode(): void {
    document.documentElement.classList.toggle('dark-theme', this.isDarkMode);
    document.body.classList.toggle('dark-theme', this.isDarkMode);
  }

  refreshSessionData(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.usuarioActual = this.currentUser || {}; 

    if (!this.currentUser) {
      this.router.navigate(['/login']);
      return;
    }
    
    if (this.usuarioActual?.tipo_usuario === 'presidente') {
      this.currentRole = 'presidente'; 
    } else {
      this.currentRole = this.usuarioActual?.tipo_usuario || this.currentUser.role || 'vecino';
    }
    
    this.cargarJuntas(); 
  }

  cargarJuntas() {
    this.http.get<any[]>(this.apiUrlJuntas).subscribe({
      next: (data) => {
        this.comunidadesGlobales = data.map(j => ({
          id: j.id_junta_vecinos, 
          nombre: j.nombre_junta, 
          comuna: 'Mi Sector',
          descripcion: 'Comunidad registrada en el sistema.',
          jefeRut: '', 
          miembrosRuts: [] 
        }));

        const miJuntaId = this.usuarioActual?.junta_vecinos_id_junta_vecinos;

        if (this.currentRole === 'admin') {
          this.solicitudesJefeAdmin = this.authService.getSolicitudesPendientes();
        } 
        else if (this.currentRole === 'presidente' || this.currentRole === 'jefe') {
          this.miComunidadJefe = this.comunidadesGlobales.find(c => c.id == miJuntaId) || null;
          this.solicitudesVecinosJefe = [];
        } 
        else if (this.currentRole === 'vecino') {
          if (miJuntaId != null && miJuntaId != 'null' && miJuntaId != 0 && miJuntaId != '0') {
            this.misComunidadesVecino = this.comunidadesGlobales.filter(c => c.id == miJuntaId);
          } else {
            this.misComunidadesVecino = [];
          }
        }

        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error al cargar las juntas vecinales desde el servidor:', err);
        this.misComunidadesVecino = [];
        this.cdr.detectChanges(); 
      }
    });
  }

  get comunidadesAdminFiltradas(): Comunidad[] {
    if (!this.searchComunidad.trim()) return this.comunidadesGlobales;
    const term = this.searchComunidad.toLowerCase();
    return this.comunidadesGlobales.filter(c => 
      c.nombre.toLowerCase().includes(term) || c.comuna.toLowerCase().includes(term)
    );
  }

  get comunidadSeleccionada(): Comunidad | undefined {
    return this.comunidadesGlobales.find(c => c.id == this.selectedComunidadId);
  }

  abrirFeed(comunidadId: string | number): void {
    this.selectedComunidadId = comunidadId;
    this.vistaActual = 'feed';
    this.cdr.detectChanges();
  }

  volverALista(): void {
    this.vistaActual = 'lista';
    this.selectedComunidadId = null;
    this.refreshSessionData();
  }

  abrirModalPostulacionJefe(): void {
    this.motivoPostulacionJefe = '';
    this.isPostularJefeOpen = true;
  }

  cerrarModalPostulacionJefe(): void {
    this.isPostularJefeOpen = false;
  }

  enviarPostulacionJefe(): void {
    if (!this.currentUser) return;
    
    const solicitud = {
      rut_usuario: this.usuarioActual?.rut || this.currentUser.rut,
      correo_usuario: this.usuarioActual?.correo || this.currentUser.correo,
      nombre_junta_nueva: this.nuevaComunidadNombre.trim(),
      motivo: this.motivoPostulacionJefe.trim()
    };

    this.http.post('http://localhost:3000/api/solicitudes', solicitud).subscribe({
      next: () => {
        alert('Tu postulación para crear la junta ha sido enviada al administrador.');
        this.cerrarModalPostulacionJefe();
        this.nuevaComunidadNombre = '';
        this.motivoPostulacionJefe = '';
      },
      error: (err) => {
        console.error('Error al enviar postulación:', err);
        alert('Hubo un error al enviar tu solicitud.');
      }
    });
  }

  resolverSolicitudJefe(rut: string, aprobar: boolean): void {
    this.authService.resolverSolicitud(rut, aprobar);
    this.refreshSessionData();
  }

  resolverSolicitudVecino(id: number, aprobar: boolean): void {
    this.solicitudesVecinosJefe = this.solicitudesVecinosJefe.filter(sol => sol.id !== id);
    this.refreshSessionData();
  }

  abrirModalCrear(): void {
    this.nuevaComunidadNombre = '';
    this.isModalCrearComunidadOpen = true;
  }
  
  cerrarModalCrear(): void {
    this.isModalCrearComunidadOpen = false;
  }

  crearComunidad(): void {
    if(!this.nuevaComunidadNombre.trim()) {
      alert('Por favor, ingresa el nombre de la junta.');
      return;
    }

    const correoUser = this.usuarioActual?.correo || this.currentUser?.correo;

    const nuevaJunta = {
      nombre_junta: this.nuevaComunidadNombre.trim(),
      correo_creador: correoUser 
    };

    this.http.post(this.apiUrlJuntas, nuevaJunta).subscribe({
      next: (respuesta: any) => {
        alert(`¡La junta "${this.nuevaComunidadNombre}" ha sido registrada!`);
        
        if (this.usuarioActual && respuesta.id_junta) {
          this.usuarioActual.junta_vecinos_id_junta_vecinos = respuesta.id_junta;
        }

        this.cerrarModalCrear();
        this.cargarJuntas(); 
      },
      error: (err) => {
        console.error('Error al intentar crear la junta en la base de datos:', err);
        alert('Ocurrió un error al guardar la junta. Revisa tu backend.');
      }
    });
  }

  cargarEventos() {
    this.http.get<FeedItem[]>(this.apiUrlEventos).subscribe({
      next: (data) => {
        this.feedItems = data || [];
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error('Error al cargar la base de datos de eventos:', err);
      }
    });
  }

  abrirModalEvento() {
    this.isCrearEventoOpen = true;
  }

  cerrarModalEvento() {
    this.isCrearEventoOpen = false;
    this.nuevoEvento = { type: 'aviso', title: '', description: '', author: '', time: '', price: '', location: '' };
  }

  guardarEvento() {
    if (!this.nuevoEvento.title || !this.nuevoEvento.description) {
      alert('Por favor completa el título y la descripción.');
      return;
    }

    this.nuevoEvento.author = this.currentUser?.nombre || 'Vecino';
    this.nuevoEvento.time = new Date().toLocaleDateString('es-CL');
    this.nuevoEvento.comunidadId = this.selectedComunidadId || 'default';

    if (this.nuevoEvento.type === 'aviso') this.nuevoEvento.icon = 'megaphone-outline';
    if (this.nuevoEvento.type === 'marketplace') this.nuevoEvento.icon = 'pricetag-outline';
    if (this.nuevoEvento.type === 'reporte') this.nuevoEvento.icon = 'shield-checkmark-outline';

    this.http.post(this.apiUrlEventos, this.nuevoEvento).subscribe({
      next: () => {
        alert('Evento creado exitosamente');
        this.cerrarModalEvento();
        this.cargarEventos();
      },
      error: (err) => {
        console.error('Error al guardar el evento:', err);
        alert('Hubo un error al crear el evento en el servidor.');
      }
    });
  }

  marcarGestionado(item: FeedItem): void {
    item.status = 'Resuelto';
  }

  eliminarItem(id?: number): void {
    if (id === undefined) return;
    this.feedItems = this.feedItems.filter(item => item.id !== id);
  }

  get filteredFeedItems(): FeedItem[] {
    let items = this.feedItems || [];
    if (this.selectedComunidadId) {
      items = items.filter(item => item.comunidadId == this.selectedComunidadId || !item.comunidadId);
    }
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      items = items.filter(item => item.title.toLowerCase().includes(term) || item.description.toLowerCase().includes(term));
    }
    return items;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  hacerPresidente(id: number) {
    (this.authService as any).ascenderUsuario(id).subscribe({
      next: (respuesta: any) => {
        alert('¡Usuario ascendido a presidente exitosamente!');
      },
      error: (error: any) => {
        console.error('Error al intentar ascender al usuario:', error);
        alert('Hubo un error al ascender al usuario.');
      }
    });
  }

  // 1. El presidente envía la invitación a la nueva ruta
  vincularVecino() {
    const datos = {
      correo: this.correoVecinoVincular,
      idJunta: this.idJuntaVincular
    };

    this.http.post('http://localhost:3000/api/notificaciones/invitar', datos).subscribe({
      next: (respuesta: any) => {
        if(respuesta.exito) {
          alert(respuesta.mensaje);
          this.correoVecinoVincular = ''; 
          this.idJuntaVincular = null as any;
        } else {
          alert('Error: ' + respuesta.mensaje);
        }
      },
      error: (err) => {
        alert('Ocurrió un error al enviar la invitación.');
        console.error(err);
      }
    });
  }

  // 2. Traer las invitaciones pendientes del usuario actual
  cargarNotificaciones() {
    const correoUser = this.usuarioActual?.correo || this.currentUser?.correo;
    if (!correoUser) return;

    this.http.post('http://localhost:3000/api/notificaciones/mis-notificaciones', { correo: correoUser }).subscribe({
      next: (data: any) => {
        this.misNotificaciones = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error al cargar notificaciones:', err)
    });
  }

  // 3. El vecino decide qué hacer con la invitación
  responderNotificacion(idNoti: number, accion: 'aceptar' | 'rechazar') {
    const correoUser = this.usuarioActual?.correo || this.currentUser?.correo;
    
    this.http.post('http://localhost:3000/api/notificaciones/responder', { idNoti, accion, correo: correoUser }).subscribe({
      next: (respuesta: any) => {
        alert(respuesta.mensaje);
        this.cargarNotificaciones(); // Recarga la campana para que desaparezca
        
        // Si aceptó, refrescamos la sesión para que le aparezca la junta de inmediato
        if (accion === 'aceptar') {
          this.refreshSessionData(); 
        }
      },
      error: (err) => alert('Error al procesar la respuesta.')
    });
  }
}