import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export type UserRole = 'vecino' | 'jefe' | 'admin';

export interface SolicitudJefe {
  rut: string;
  nombre: string;
  email: string;
  sector: string;
  motivo: string;
  fecha: string;
}

export interface UserSession {
  rut: string;
  nombre: string;
  correo: string;
  tipo_usuario: string;
  role: UserRole;
  sector: string;
  solicitoJefe?: boolean;
  junta_vecinos_id_junta_vecinos: number;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:3000/api/usuarios'; 
  private sessionKey = 'barrio_active_session_v2';
  private currentUser: UserSession | null = null;
  private solicitudes: SolicitudJefe[] = [];

  constructor(private http: HttpClient) {
    const savedSession = localStorage.getItem(this.sessionKey);
    if (savedSession) {
      this.currentUser = JSON.parse(savedSession);
    }
  }

  validarRut(rutCompleto: string): boolean {
    return true;
  }

  register(nombre: string, rut: string, correo: string, contraseña: string, sector_villa: string): Observable<any> {
    const nuevoUsuario = {
      nombre: nombre.trim(),
      rut: rut.replace(/[^0-9kK]/g, '').toUpperCase(),
      correo: correo.trim().toLowerCase(),
      contraseña: contraseña,
      sector_villa: sector_villa
    };
    return this.http.post(this.apiUrl, nuevoUsuario);
  }

  // --- NUEVO: Método para validar credenciales con el backend de forma segura ---
  loginMysql(correo: string, contraseña: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, { 
      correo: correo.trim().toLowerCase(), 
      contraseña 
    });
  }

  getUsuariosMysql(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  setCurrentUser(user: any): void {
    user.role = (user.tipo_usuario?.toLowerCase() as UserRole) || 'vecino';
    user.sector = user.sector || 'Central';
    this.currentUser = user as UserSession;
    localStorage.setItem(this.sessionKey, JSON.stringify(user));
  }

  getCurrentUser(): UserSession | null {
    return this.currentUser;
  }

  logout(): void {
    this.currentUser = null;
    localStorage.removeItem(this.sessionKey);
  }

  postularAJefe(rut: string, motivo: string): { ok: boolean; msg: string } {
    if (this.currentUser) {
      this.currentUser.solicitoJefe = true;
      localStorage.setItem(this.sessionKey, JSON.stringify(this.currentUser));
    }
    const existe = this.solicitudes.find(s => s.rut === rut);
    if (!existe && this.currentUser) {
      this.solicitudes.push({
        rut: this.currentUser.rut,
        nombre: this.currentUser.nombre,
        email: this.currentUser.correo || '',
        sector: this.currentUser.sector || 'Central',
        motivo,
        fecha: new Date().toLocaleDateString('es-CL')
      });
    }
    return { ok: true, msg: 'Postulación enviada correctamente a revisión.' };
  }

  getSolicitudesPendientes(): SolicitudJefe[] {
    return this.solicitudes;
  }

  resolverSolicitud(rut: string, aprobar: boolean): void {
    const user = this.solicitudes.find(s => s.rut === rut);
    if (user && aprobar) {
      if (this.currentUser && this.currentUser.rut === rut) {
        this.currentUser.role = 'jefe';
        this.currentUser.tipo_usuario = 'jefe';
        localStorage.setItem(this.sessionKey, JSON.stringify(this.currentUser));
      }
    }
    this.solicitudes = this.solicitudes.filter(s => s.rut !== rut);
  }

  ascenderUsuario(id: number): Observable<any> {
    return this.http.patch(`${this.apiUrl}/${id}/ascender`, {});
  }
}