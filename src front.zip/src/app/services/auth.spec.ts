import { Injectable } from '@angular/core';

export type UserRole = 'vecino' | 'jefe' | 'admin';

export interface UserSession {
  email: string;
  nombre: string;
  role: UserRole;
  sector?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // Mock de usuarios registrados con sus roles asignados por el sistema/admin
  private mockUsers: UserSession[] = [
    { email: 'vecino@barrio.cl', nombre: 'Juan Pérez', role: 'vecino', sector: 'Sector Poniente' },
    { email: 'jefe@barrio.cl', nombre: 'Carlos Mendoza', role: 'jefe', sector: 'Villa Los Álamos' },
    { email: 'admin@barrio.cl', nombre: 'Administrador General', role: 'admin' }
  ];

  private currentUser: UserSession | null = null;

  login(email: string): UserSession | null {
    const user = this.mockUsers.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (user) {
      this.currentUser = user;
      return user;
    }
    return null;
  }

  getCurrentUser(): UserSession | null {
    return this.currentUser;
  }

  logout(): void {
    this.currentUser = null;
  }
}