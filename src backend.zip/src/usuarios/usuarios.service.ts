import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Usuario } from './entities/usuario.entity';

@Injectable()
export class UsuariosService {
  constructor(
    @InjectRepository(Usuario)
    private usuarioRepository: Repository<Usuario>,
  ) {}

  create(createUsuarioDto: any) {
    const nuevo = this.usuarioRepository.create({
      ...createUsuarioDto,
      tipo_usuario: 'vecino',
    });
    return this.usuarioRepository.save(nuevo);
  }

  findAll() {
    return this.usuarioRepository.find();
  }

  async login(correo: string, contraseñaIngresada: string) {
    const usuario = await this.usuarioRepository.findOne({ where: { correo } });

    if (!usuario) {
      return { ok: false, message: 'El correo no está registrado' };
    }

    if (usuario.contraseña !== contraseñaIngresada) {
      return { ok: false, message: 'Contraseña incorrecta' };
    }

    return { ok: true, message: 'Inicio de sesión exitoso', data: usuario };
  }

  async ascenderAPresidente(id: number) {
    await this.usuarioRepository.update(id, { tipo_usuario: 'presidente' });
    return { mensaje: 'Usuario ascendido a presidente exitosamente' };
  }
}