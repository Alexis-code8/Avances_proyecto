import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('usuarios')
export class Usuario {
  @PrimaryGeneratedColumn()
  id_usuarios: number;

  @Column()
  nombre: string;

  @Column()
  rut: string;

  @Column()
  correo: string;

  @Column()
  contraseña: string;

  @Column()
  sector_villa: string;

  @Column({ default: 'vecino' })
  tipo_usuario: string;

  @Column({ nullable: true })
  junta_vecinos_id_junta_vecinos: number;
}