import { Controller, Get, Post, Body, Patch, Param } from '@nestjs/common';
import { UsuariosService } from './usuarios.service';

@Controller('api/usuarios')
export class UsuariosController {
  constructor(private readonly usuariosService: UsuariosService) {}

  @Post()
  create(@Body() createUsuarioDto: any) {
    return this.usuariosService.create(createUsuarioDto);
  }

  @Post('login')
  login(@Body() body: { correo: string; contraseña: string }) {
    return this.usuariosService.login(body.correo, body.contraseña);
  }

  @Get()
  findAll() {
    return this.usuariosService.findAll();
  }

  @Patch(':id/ascender')
  ascender(@Param('id') id: string) {
    return this.usuariosService.ascenderAPresidente(Number(id));
  }
}