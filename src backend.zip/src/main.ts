import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  // Habilitar CORS para permitir peticiones desde Ionic (puerto 8100)
  app.enableCors();

  await app.listen(3000);
}
bootstrap();