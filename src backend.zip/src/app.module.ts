import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsuariosModule } from './usuarios/usuarios.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: 'admin', // <--- Si tu MySQL no tiene contraseña déjalo con comillas vacías '' (si tiene, ponla aquí)
      database: 'mydb',
      autoLoadEntities: true,
      synchronize: false, // Lo dejamos en false para que respete la estructura que ya creamos en Workbench
    }),
    UsuariosModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}